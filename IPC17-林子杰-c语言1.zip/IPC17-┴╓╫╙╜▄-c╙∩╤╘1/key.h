#ifndef _KET_H_
#define _KEY_H_
#include "stm32f4xx.h"

void key_init(void);



#endif



